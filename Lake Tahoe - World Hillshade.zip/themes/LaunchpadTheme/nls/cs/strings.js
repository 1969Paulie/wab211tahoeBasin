define({
  "_themeLabel": "Motiv hlavního panelu",
  "_layout_default": "Výchozí rozvržení",
  "_layout_right": "Pravé rozvržení"
});