define({
  "_themeLabel": "Launchpad téma",
  "_layout_default": "Alapértelmezett elrendezés",
  "_layout_right": "Jobb oldali elrendezés"
});