define({
  "_widgetLabel": "Bộ điều khiển Thanh Cố định",
  "_layout_default": "Bố cục mặc định",
  "_layout_layout1": "Bố cục 0",
  "more": "Các tiện ích khác"
});